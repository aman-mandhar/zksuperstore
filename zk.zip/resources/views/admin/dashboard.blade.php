@extends('layouts.admin')
@section('content')
Admin Dashboard
@endsection