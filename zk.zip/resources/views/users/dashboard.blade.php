@extends('layouts.admin')
@section('content')
Customer's Dashboard
@endsection 