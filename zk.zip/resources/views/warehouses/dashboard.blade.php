@extends('layouts.warehouse')
@section('content')
warehouse Dashboard
@endsection