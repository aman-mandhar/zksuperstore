@extends('layouts.admin')
@section('content')
Warehouse Dashboard
@endsection