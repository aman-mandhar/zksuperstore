

<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <form action="<?php echo e(route('stocks.index')); ?>" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Search by name" name="search" id="search" value="<?php echo e(request('search')); ?>">
                <button type="submit" class="btn btn-outline-secondary">Search</button>
            </div>
        </form>

        <h2>Stocks</h2>

        
        <table class="table">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Sale Price</th>
                    <th>Points</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($stock->item && $stock->item->prod_cat != 'Services'): ?>
                    <tr class="item-row">
                        <td>
                            <?php
                                $img = $stock->item->prod_pic; // Assuming there is a relationship between Stock and Item
                            ?>
                                <img src="<?php echo e(asset($img)); ?>" alt="Product Image" style="width: 60px; height: 60px; object-fit: cover;">

                        </td>
                        <td>
                            <?php
                                $name = $stock->item->name; // Assuming there is a relationship between Stock and Item
                                $description = $stock->item->description; // Assuming there is a relationship between Stock and Item
                            ?>
                            <?php echo e($name); ?>

                            <br>
                            <small><?php echo e($description); ?></small>
                        </td>
                        <td><?php echo e($stock->sale_price); ?></td>
                        <?php if($user->user_role == 2): ?>
                            <td><?php echo e(0.50 * $stock->tot_points); ?></td>
                        <?php elseif($user->user_role == 4): ?>
                            <td><?php echo e(0.25 * $stock->tot_points); ?></td>
                        <?php else: ?>
                            <td>
                                0
                            </td>                    
                        <?php endif; ?>
                        <td>
                            <a href="<?php echo e(route('stocks.bill', $stock->id)); ?>" class="btn btn-warning">Sale</a>
                            <?php if($user->user_role == 2): ?>
                            <a href="<?php echo e(route('stocks.transfer', $stock->id)); ?>" class="btn btn-warning">Required</a>
                            <?php elseif($user->user_role == 3): ?>
                            <a href="<?php echo e(route('stocks.transfer', $stock->id)); ?>" class="btn btn-warning">Add Stock</a>
                            <?php elseif($user->user_role == 4): ?>
                            <a href="<?php echo e(route('stocks.transfer', $stock->id)); ?>" class="btn btn-warning">Required</a>
                            <?php else: ?>
                            <a href="<?php echo e(route('stocks.add', $stock->id)); ?>" class="btn btn-warning">Add Stock</a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('stocks.edit', $stock->id)); ?>" class="btn btn-warning">Edit</a>
                            <form action="<?php echo e(route('stocks.destroy', $stock->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <!-- Handle the case where there are no stocks -->
                    <tr>
                        <td colspan="9">No stocks found</td>
                    </tr>
                <?php endif; ?> 
            </tbody>
        </table>

        
        <a href="<?php echo e(route('items.create')); ?>" class="btn btn-success">Add Item</a>
    </div>

    <script>
        document.getElementById('search').addEventListener('input', function () {
            var searchValue = this.value.toLowerCase();

            // Loop through each row in the table body
            document.querySelectorAll('.item-row').forEach(function (row) {
                var itemName = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                row.style.display = itemName.includes(searchValue) ? 'table-row' : 'none';
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\zk\resources\views/stocks/index.blade.php ENDPATH**/ ?>