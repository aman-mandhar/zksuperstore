

<?php $__env->startSection('content'); ?>
    <div class="container col-md-6">
        <h4>User Details</h4>
        <hr>
        <form method="POST" action="<?php echo e(route('users.update', $user->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
        <table
            class="table table-striped table-bordered table-hover table-condensed">
            <tbody>
            <tr>
                <td>Name</td>
                <td><?php echo e($user->name); ?></td>
            </tr>
            <tr>
                <td>Mobile Number</td>
                <td>
                    <input id="mobile_number" type="text" class="form-control <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="mobile_number" value="<?php echo e($user->mobile_number); ?>" required autocomplete="mobile_number">
                    <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <td>Email</td>
                <td><?php echo e($user->email); ?></td>
            </tr>
            <tr>
                <td>Referral Mobile Number</td>
                <td><?php echo e($user->ref_mobile_number); ?></td>
            </tr>
            <tr>
                <td>Referral Name</td>
                <td>
                        <span id="referral_name"></span>
                </td>
            </tr>
            <tr>
                <td>User Role</td>
                <td>
                        <select id="user_role" class="form-control <?php $__errorArgs = ['user_role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="user_role" required>
                            <option value="0" <?php echo e(old('user_role') == '0' ? 'selected' : ''); ?>>Customer</option>
                            <option value="1" <?php echo e(old('user_role') == '1' ? 'selected' : ''); ?>>Admin</option>
                            <option value="2" <?php echo e(old('user_role') == '2' ? 'selected' : ''); ?>>Store</option>
                            <option value="3" <?php echo e(old('user_role') == '3' ? 'selected' : ''); ?>>Warehouse</option>
                            <option value="4" <?php echo e(old('user_role') == '4' ? 'selected' : ''); ?>>Sub-Warehouse</option>
                            <option value="5" <?php echo e(old('user_role') == '5' ? 'selected' : ''); ?>>Employee</option>
                            <option value="6" <?php echo e(old('user_role') == '6' ? 'selected' : ''); ?>>Merchant</option>
                            <option value="7" <?php echo e(old('user_role') == '7' ? 'selected' : ''); ?>>Transporter</option>
                            <option value="8" <?php echo e(old('user_role') == '8' ? 'selected' : ''); ?>>Delivery Partner</option>
                            <option value="9" <?php echo e(old('user_role') == '9' ? 'selected' : ''); ?>>Business Promoter</option>
                            <!-- Add more options for different user roles if needed -->
                        </select>
                        <?php $__errorArgs = ['user_role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <td>City</td>
                <td>
                    <input id="city" type="text" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="city" value="<?php echo e($user->city); ?>" required autocomplete="city">
                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <td>GST Number</td>
                <td>
                    <input id="gst_no" type="text" class="form-control <?php $__errorArgs = ['gst_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gst_no" value="<?php echo e($user->gst_no); ?>" autocomplete="gst_no">
                    <?php $__errorArgs = ['gst_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </td>
            </tr>
            <tr>
                <td>With us from</td>
                <td><?php echo e($user->created_at); ?></td>
            </tr>
            </tbody>
        </table>
        <button type="submit" class="btn btn-primary">Update</button>
        </form>
        <table>
            <thead>
                <tr>
                    <th>User Role & Name</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>0</td>
                    <td>Customer</td>
                </tr>
                <tr>
                    <td>1</td>
                    <td>Admin</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Store</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Warehouse</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Sub-Warehouse</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Employee</td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Merchant</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Transporter</td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>Delivery Partner</td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>Business Promoter</td>
                </tr>
            </tbody>
        </table>
    </div>
    <script>
        document.getElementById('ref_mobile_number').addEventListener('blur', function() {
                // Get the referral mobile number
                var referralMobileNumber = document.getElementById('ref_mobile_number').value;

                // Make an AJAX request to get the referral name
                fetch(`/getReferralName?referralMobileNumber=${referralMobileNumber}`)
                    .then(response => response.json())
                    .then(data => {
                        // Update the Referral Name field
                        document.getElementById('referral_name').innerText = data.name;
                    })
                    .catch(error => {
                        console.error('Error fetching Referral Name:', error);
                    });
            });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\zk\resources\views/users/roles.blade.php ENDPATH**/ ?>