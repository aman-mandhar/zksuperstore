
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('sales.new')); ?>" method="GET" class="mb-3">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Customer mobile number" name="search" id="search" value="<?php echo e(request('search')); ?>">
            <button type="submit" class="btn btn-outline-secondary">Search</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\zk\resources\views/sales/new.blade.php ENDPATH**/ ?>