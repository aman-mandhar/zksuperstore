<nav class="navbar">
  <div class="nav-logo">
    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/user/images/logo.png')); ?>" alt="logo"></a>
  </div>
  <div class="nav-search">
    <select class="select-search">
        <option>All</option>
        <option value="Packet">Daily Need</option>
        <option value="Service">Service</option>
        <option value="Ticket">Ticket</option>
        <option value="Package">Package</option>
        <option value="Course">Course</option>
    </select>
    <input type="text" placeholder="Search" class="search-input">
    <div class="search-icon">
      <span class="material-symbols-outlined">search</span>
    </div>
  </div>
  <div class="banner">
      <ul class="links">
      <li>
    <div>
    <a href="#">
      <?php if(auth()->guard()->guest()): ?>
        <?php if(Route::has('login')): ?>
          <a href="<?php echo e(route('login')); ?>">Login</a>
        <?php endif; ?>
      <?php else: ?>
        <?php echo e(Auth::user()->city); ?>

      <?php endif; ?>
    </a>
    </li>
    </div>
  
  <div class="banner">
    <div>
    <?php if(auth()->guard()->guest()): ?>
          <?php if(Route::has('register')): ?>
            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
          <?php endif; ?>
          <?php else: ?>
          <p>Hello, <?php echo e(Auth::user()->name); ?></p>
    <?php endif; ?>
    </div>
  </div>

  <div class="banner">
    <div>
      <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
         onclick="event.preventDefault();
                       document.getElementById('logout-form').submit();">
          <?php echo e(__('Logout')); ?>

      </a>
      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
          <?php echo csrf_field(); ?>
      </form>
    </div> 
  </div>

  <div class="banner">
    <a href="#"><p>Orders</p></a>
  </div>

  <div class="banner">
    <a href="#">
      <i class="fa fa-shopping-cart"></i>
      </a>
      <p>Cart</p>
  </div>

</nav>

<div class="banner">
  <div class="banner-content">
    <div class="panel">
      <span class="material-symbols-outlined">menu</span>
      <a href="#">All</a>
    </div>

    <ul class="links">
<li><a href="#">Today's Deals</a></li>
<li><a href="#">Bus Tickets</a></li>
<li><a href="#">Tour Packages</a></li>
<li><a href="#">Courses</a></li>
<li><a href="#">Electronics</a></li>
<li><a href="#">Digital</a></li>
</ul>
<div class="deals">
<a href="#">Recycle Units</a>
</div>
  </div>
</div><?php /**PATH F:\xampp\htdocs\zk\resources\views/layouts/inc/user/navbar.blade.php ENDPATH**/ ?>