

<?php $__env->startSection('content'); ?>
    <div class="container col-md-6">
        <h4>User Details</h4>
        <hr>
        <table
            class="table table-striped table-bordered table-hover table-condensed">
            <tbody>
            <tr>
                <td>Name</td>
                <td><?php echo e($user->name); ?></td>
            </tr>
            <tr>
                <td>Mobile Number</td>
                <td><?php echo e($user->mobile_number); ?></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><?php echo e($user->email); ?></td>
            </tr>
            <tr>
                <td>Referral Mobile Number</td>
                <td><?php echo e($user->ref_mobile_number); ?></td>
            </tr>
            <tr>
                <td>Referral Name</td>
                <td> <?php if($Refname->isNotEmpty()): ?>
                    <p><?php echo e($Refname->first()->name); ?></p>
                    <?php else: ?>
                    <p>Referral Name not found</p>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>User Role</td>
                <td><?php echo e($user->user_role); ?></td>
            </tr>
            <tr>
                <td>With us from</td>
                <td><?php echo e($user->created_at); ?></td>
            </tr>
            </tbody>
        </table>
        <table>
            <thead>
                <tr>
                    <th>User Role & Name</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>0</td>
                    <td>Customer</td>
                </tr>
                <tr>
                    <td>1</td>
                    <td>Admin</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Store</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Warehouse</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Sub-Warehouse</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Employee</td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Merchant</td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Transporter</td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>Delivery Partner</td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>Business Promoter</td>
                </tr>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\zk\resources\views/users/show.blade.php ENDPATH**/ ?>