

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Search User by Mobile Number</h2>
    <p>Enter the mobile number of the user to search for.</p>
    <form action="<?php echo e(route('sales.bill')); ?>" method="GET" class="mb-3">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Enter Mobile Number" name="mobile_number" value="<?php echo e(request('mobile_number')); ?>">
            <button type="submit" class="btn btn-outline-secondary">Search</button>
        </div>
    </form>

    <div class="card">
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Mobile Number</th>
                        <th>Name</th>
                        <th>Referral</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="user-row">
                        <td><?php echo e($user->mobile_number); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->referral); ?></td>
                        <td>
                            <a href="<?php echo e(route('sales.bill', $user->id)); ?>" class="btn btn-warning">Sale</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">No users found</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    document.getElementById('mobile_number').addEventListener('input', function () {
        var searchValue = this.value.toLowerCase();

        // Loop through each row in the table body
        document.querySelectorAll('.user-row').forEach(function (row) {
            var mobileNumber = row.querySelector('td:first-child').textContent.toLowerCase();
            row.style.display = mobileNumber.includes(searchValue) ? 'table-row' : 'none';
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\zk\resources\views/sales/bill.blade.php ENDPATH**/ ?>