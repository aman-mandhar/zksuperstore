
<?php $__env->startSection('content'); ?>
    <h5>Add New Subcategory</h5>
    <form action="<?php echo e(route('subcategories.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="category_id">Category</label>
            <select name="category_id" id="category_id" class="form-control">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <input type="text" name="name" id="name" placeholder="Subcategory Name">
        <button type="submit">Add Subcategory</button>
    </form>
    <h5>All Subcategories</h5>
    <table class="table col-md-6">
        <thead class="col-md-6">
            <tr class="row-md-6">
                <th class="col-md-3">Subcategory Name</th>
                <th class="col-md-3">Category Name</th>
                <th class="col-md-3">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="col-md-3"><?php echo e($subcategory->name); ?></td>
                    <td class="col-md-3"><?php echo e($subcategory->category->name); ?></td>
                    <td class="col-md-3">
                        <form action="<?php echo e(route('subcategories.destroy', $subcategory->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\zk\resources\views/items/subcategories.blade.php ENDPATH**/ ?>