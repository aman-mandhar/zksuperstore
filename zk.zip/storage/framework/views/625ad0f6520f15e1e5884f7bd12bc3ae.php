

<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <form action="<?php echo e(route('items.index')); ?>" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Search by name" name="search" id="search" value="<?php echo e(request('search')); ?>">
                <button type="submit" class="btn btn-outline-secondary">Search</button>
            </div>
        </form>

        <h2>Items</h2>

        
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Category</th>
                    <th>Type</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="item-row">
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->description); ?></td>
                        <td><?php echo e($item->prod_cat); ?></td>
                        <td><?php echo e($item->type); ?></td>
                        <td>
                            <img src="<?php echo e(asset($item->prod_pic)); ?>" alt="Product Image" style="width: 60px; height: 60px; object-fit: cover;">
                        </td>

                        <td>
                            <a href="<?php echo e(route('stocks.add', $item->id)); ?>" class="btn btn-warning">Add Stock</a>
                            <a href="<?php echo e(route('items.edit', $item->id)); ?>" class="btn btn-warning">Edit</a>
                            <form action="<?php echo e(route('items.destroy', $item->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">No items found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        
        <a href="<?php echo e(route('items.create')); ?>" class="btn btn-success">Add Item</a>
    </div>

    <script>
        document.getElementById('search').addEventListener('input', function () {
            var searchValue = this.value.toLowerCase();

            // Loop through each row in the table body
            document.querySelectorAll('.item-row').forEach(function (row) {
                var itemName = row.querySelector('td:first-child').textContent.toLowerCase();
                row.style.display = itemName.includes(searchValue) ? 'table-row' : 'none';
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\zk\resources\views/items/index.blade.php ENDPATH**/ ?>