<nav class="navbar">
  <div class="nav-logo">
    <a href="/"><img src="<?php echo e(asset('assets/user/images/logo.png')); ?>" alt="logo"></a>
    <b>From : </b>
    <a href="#" class="location">
      <?php if(auth()->guard()->guest()): ?>
        <?php if(Route::has('login')): ?>
          <a href="<?php echo e(route('login')); ?>">Login</a>
        <?php endif; ?>
      <?php else: ?>
        <?php echo e(Auth::user()->city); ?>

      <?php endif; ?>
    </a>
  </div>
  
  <div class="nav-search">
    <select class="select-search">
      <option>All</option>
      <option value="Packet">Daily Need</option>
      <option value="Service">Service</option>
      <option value="Ticket">Ticket</option>
      <option value="Package">Package</option>
      <option value="Course">Course</option>
    </select>
    <input type="text" placeholder="Search" class="search-input">
    <div class="search-icon">
      <span class="material-symbols-outlined">search</span>
    </div>
  </div>

  <div class="sign-in">
    <?php if(auth()->guard()->guest()): ?>
      <?php if(Route::has('login')): ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
        </li>
      <?php endif; ?>

      <?php if(Route::has('register')): ?>
        <li>
          <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
        </li>
      <?php endif; ?>
    <?php else: ?>
      <li class="nav-item dropdown">
        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
          <p>Hello, <?php echo e(Auth::user()->name); ?></p>
        </a>

        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
              document.getElementById('logout-form').submit();">
            <?php echo e(__('Logout')); ?>

          </a>

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
          </form>
        </div>
      </li>
    <?php endif; ?>
  </div>
</nav>
<?php /**PATH E:\laragon\www\zk\resources\views/layouts/inc/store/navbar.blade.php ENDPATH**/ ?>