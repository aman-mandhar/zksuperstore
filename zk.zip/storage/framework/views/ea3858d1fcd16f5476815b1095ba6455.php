<?php $__env->startSection('content'); ?>        
            <img src="<?php echo e(asset('assets/user/images/hero.jpg')); ?>" alt="card"/>
            <section class="shop-section">
              <div class="shop-images">
                <div class="shop-link">
                  <h3>Laptops</h3>
                  <img src="<?php echo e(asset('assets/user/images/img-1.png')); ?>" alt="card">
                  <a href="#">Shop now</a>
                </div>
                <div class="shop-link">
                  <h3>Smart Watches</h3>
                  <img src="<?php echo e(asset('assets/user/images/img-2.png')); ?>" alt="card">
                  <a href="#">Shop now</a>
                </div>
                <div class="shop-link">
                  <h3>Strip Lights</h3>
                  <img src="<?php echo e(asset('assets/user/images/img-3.png')); ?>" alt="card">
                  <a href="#">Shop now</a>
                </div>
                <div class="shop-link">
                  <h3>Home Refresh Ideas</h3>
                  <img src="<?php echo e(asset('assets/user/images/img-4.png')); ?>" alt="card">
                  <a href="#">Shop now</a>
                </div>
              </div>
            </section>
         <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    </body>
    
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\zk\resources\views/welcome.blade.php ENDPATH**/ ?>