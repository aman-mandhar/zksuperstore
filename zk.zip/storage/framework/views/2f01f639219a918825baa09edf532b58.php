<footer>
    <a href="#" class="footer-title">
      Back to top
    </a>
    <div class="footer-items">
      <ul>
        <h3>Get to Know Us</h3>
        <li><a href="#">About us</a></li>
        <li><a href="#">Careers</a></li>
        <li><a href="#">Press Release</a></li>
        <li><a href="#">Contact us</a></li>
      </ul>
      <ul>
        <h3>Connect with Us</h3>
        <li><a href="#">Facebook</a></li>
        <li><a href="#">Twitter</a></li>
        <li><a href="#">Instagram</a></li>
      </ul>
      <ul>
        <h3>Make Money with Us</h3>
        <li><a href="#">Sell on ZK</a></li>
        <li><a href="#">Sell under ZK</a></li>
        <li><a href="#">Become an Associate</a></li>
      </ul>
      <ul>
        <h3>Let Us Help You</h3>
        <li><a href="#">List of Stores</a></li>
        <li><a href="#">Your Account</a></li>
        <li><a href="#">Return Centre</a></li>
        <li><a href="#">100% Purchase Protection</a></li>
        <li><a href="#">App Download</a></li>
        <li><a href="#">Help</a></li>
      </ul>
    </div>
  </footer><?php /**PATH F:\xampp\htdocs\zk\resources\views/layouts/inc/user/footer.blade.php ENDPATH**/ ?>