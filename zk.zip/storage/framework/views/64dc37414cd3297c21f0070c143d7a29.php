
<?php $__env->startSection('content'); ?>
Customer's Dashboard
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\zk\resources\views/users/dashboard.blade.php ENDPATH**/ ?>