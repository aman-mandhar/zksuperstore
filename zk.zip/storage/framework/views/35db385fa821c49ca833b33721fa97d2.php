
<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Create New Customer</h2>

    <form method="POST" action="<?php echo e(route('users.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="col-md-6">
            <select id="city" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="city" required>
                <option value="">Select nearest City</option>
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($city); ?>" <?php echo e(old('city') == $city ? 'selected' : ''); ?>><?php echo e($city); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    
            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
        
            <div class="col-md-6">
                <input id="name" type="text" hidden class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="Not Set" placeholder="Name of User" default="Not set" required>
                <input id="mobile_number" type="text" class="form-control <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="mobile_number" placeholder="Mobile Number" oninput="updateEmail()" required autocomplete="mobile_number" value=<?php echo e($search); ?>>
                <input id="ref_mobile_number" type="text" class="form-control <?php $__errorArgs = ['ref_mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ref_mobile_number" placeholder="Refferal Mobile Number" value="<?php echo e(old('ref_mobile_number', '0000000000')); ?>" required autocomplete="ref_mobile_number">
                <input id="gst_no" placeholder="GST No." class="form-control <?php $__errorArgs = ['gst_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gst_no" value="<?php echo e(old('gst_no')); ?>" autocomplete="gst_no">
                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" required autocomplete="email" placeholder="Customer Email" value="<?php echo e($search); ?>@zksuperstore.com">
                <input id="password" type="password" hidden class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" value="<?php echo e(old('password', '12345678')); ?>" required autocomplete="new-password">
                <input id="password-confirm" type="password" hidden class="form-control" name="password_confirmation" value="<?php echo e(old('password', '12345678')); ?>" required autocomplete="new-password">
            </div>
            <div class="col-md-6">
                <select id="user_role" hidden class="form-control <?php $__errorArgs = ['user_role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="user_role" required>
                    <option value="0" <?php echo e(old('user_role') == '0' ? 'selected' : ''); ?>>Customer</option>
                    <option value="1" <?php echo e(old('user_role') == '1' ? 'selected' : ''); ?>>Admin</option>
                    <option value="2" <?php echo e(old('user_role') == '2' ? 'selected' : ''); ?>>Store</option>
                    <option value="3" <?php echo e(old('user_role') == '3' ? 'selected' : ''); ?>>Warehouse</option>
                    <option value="4" <?php echo e(old('user_role') == '4' ? 'selected' : ''); ?>>Sub-Warehouse</option>
                    <option value="5" <?php echo e(old('user_role') == '5' ? 'selected' : ''); ?>>Employee</option>
                    <option value="6" <?php echo e(old('user_role') == '6' ? 'selected' : ''); ?>>Merchant</option>
                    <option value="7" <?php echo e(old('user_role') == '7' ? 'selected' : ''); ?>>Transporter</option>
                    <option value="8" <?php echo e(old('user_role') == '8' ? 'selected' : ''); ?>>Delivery Partner</option>
                    <option value="9" <?php echo e(old('user_role') == '9' ? 'selected' : ''); ?>>Business Promoter</option>
                    <!-- Add more options for different user roles if needed -->
                </select>

                <?php $__errorArgs = ['user_role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="row mb-0">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn btn-primary">
                    <?php echo e(__('Register')); ?>

                </button>
            </div>
        </div>
    </form>
</div>
<script>
    // Function to update the email field based on mobile_number
    function updateEmail() {
        var mobileNumberInput = document.getElementById('mobile_number');
        var emailInput = document.getElementById('email');

        if (mobileNumberInput && emailInput) {
            var mobileNumberValue = mobileNumberInput.value;
            var domain = '@zksuperstore.com';

            // Update the email input value
            emailInput.value = mobileNumberValue + domain;
        }
    }

    // Attach the event listener to the mobile_number input
    document.getElementById('mobile_number').addEventListener('input', updateEmail);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\zk\resources\views/sales/new_user.blade.php ENDPATH**/ ?>