
<?php $__env->startSection('content'); ?>
<table class="table">
    <thead>
        <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Sale Price</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($stock->item && $stock->item->prod_cat != 'Services'): ?>
            <tr class="item-row">
                <td>
                    <?php
                        $img = $stock->item->prod_pic; // Assuming there is a relationship between Stock and Item
                    ?>
                        <img src="<?php echo e(asset($img)); ?>" alt="Product Image" style="width: 60px; height: 60px; object-fit: cover;">

                </td>
                <td>
                    <?php
                        $name = $stock->item->name; // Assuming there is a relationship between Stock and Item
                        $description = $stock->item->description; // Assuming there is a relationship between Stock and Item
                    ?>
                    <?php echo e($name); ?>

                    <br>
                    <small><?php echo e($description); ?></small>
                </td>
                <td>
                    <a href="<?php echo e(route('sales.bill', $stock->id, $user->id)); ?>" class="btn btn-warning">Sale</a>
                    <?php if($user->user_role == 2): ?>
                    <a href="<?php echo e(route('stocks.transfer', $stock->id)); ?>" class="btn btn-warning">Required</a>
                    <?php elseif($user->user_role == 3): ?>
                    <a href="<?php echo e(route('stocks.transfer', $stock->id)); ?>" class="btn btn-warning">Add Stock</a>
                    <?php elseif($user->user_role == 4): ?>
                    <a href="<?php echo e(route('stocks.transfer', $stock->id)); ?>" class="btn btn-warning">Required</a>
                    <?php else: ?>
                    <a href="<?php echo e(route('stocks.add', $stock->id)); ?>" class="btn btn-warning">Add Stock</a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('stocks.edit', $stock->id)); ?>" class="btn btn-warning">Edit</a>
                    <form action="<?php echo e(route('stocks.destroy', $stock->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <!-- Handle the case where there are no stocks -->
            <tr>
                <td colspan="9">No stocks found</td>
            </tr>
        <?php endif; ?> 
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\zk\resources\views/sales/create.blade.php ENDPATH**/ ?>