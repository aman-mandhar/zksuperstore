<!-- resources/views/users/index.blade.php -->

 <!-- Extend the layout if you have one -->

<?php $__env->startSection('content'); ?>
    <h1>User Table Data</h1>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Mobile Number</th>
                <th>Referral Mobile Number</th>
                <th>User Role</th>
                <th>Email</th>
                <th>Email Verified At</th>
                <th>Password</th>
                <!-- Add more table headers for other user columns as needed -->
                <th>Created At</th>
                <th>Updated At</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->mobile_number); ?></td>
                    <td><?php echo e($user->ref_mobile_number); ?></td>
                    <td><?php echo e($user->user_role); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->email_verified_at); ?></td>
                    <td><?php echo e($user->password); ?></td>
                    <!-- Add more table cells for other user columns as needed -->
                    <td><?php echo e($user->created_at); ?></td>
                    <td><?php echo e($user->updated_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\zk\resources\views/users/index.blade.php ENDPATH**/ ?>