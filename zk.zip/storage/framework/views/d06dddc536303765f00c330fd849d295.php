<!-- resources/views/users/index.blade.php -->

 <!-- Extend the layout if you have one -->

<?php $__env->startSection('content'); ?>
    <h1>User Table Data</h1>

    <table>
        <thead>
            <tr>
                <th class="col-md-2">Name</th>
                <th class="col-md-2">Mobile Number</th>
                <th class="col-md-2">Referral Mobile Number</th>
                <th class="col-md-2">User Role</th>
                <th class="col-md-2">Email</th>
                <th class="col-md-2">Created At</th>
                <th class="col-md-2">Action</th>
                <th>destroy</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->mobile_number); ?></td>
                    <td><?php echo e($user->ref_mobile_number); ?></td>
                    <td><?php echo e($user->user_role); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->created_at); ?></td>
                    <td>
                        <a href="<?php echo e(route('users.show', $user->id)); ?>">View</a>
                        <a href="<?php echo e(route('users.roles', $user->id)); ?>">Change Role</a>
                    </td>
                    <td>
                        <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <table>
        <thead>
            <tr>
                <th>User Role & Name</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>0</td>
                <td>Customer</td>
            </tr>
            <tr>
                <td>1</td>
                <td>Admin</td>
            </tr>
            <tr>
                <td>2</td>
                <td>Store</td>
            </tr>
            <tr>
                <td>3</td>
                <td>Warehouse</td>
            </tr>
            <tr>
                <td>4</td>
                <td>Sub-Warehouse</td>
            </tr>
            <tr>
                <td>5</td>
                <td>Employee</td>
            </tr>
            <tr>
                <td>6</td>
                <td>Merchant</td>
            </tr>
            <tr>
                <td>7</td>
                <td>Transporter</td>
            </tr>
            <tr>
                <td>8</td>
                <td>Delivery Partner</td>
            </tr>
            <tr>
                <td>9</td>
                <td>Business Promoter</td>
            </tr>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

                        

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\zk\resources\views/users/index.blade.php ENDPATH**/ ?>