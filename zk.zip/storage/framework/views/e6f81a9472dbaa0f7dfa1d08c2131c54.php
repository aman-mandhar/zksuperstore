

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Create Retail Store</div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('retails.store')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="user_id">User:</label>
                                <select name="user_id" id="user_id" class="form-control" required>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($user->user_role == 2): ?>
                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="store_add">Store Address:</label>
                                <input type="text" name="store_add" id="store_add" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="city">City:</label>
                                <input type="text" name="city" id="city" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="manager">Manager:</label>
                                <input type="text" name="manager" id="manager" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="mobile_no">Mobile Number:</label>
                                <input type="text" name="mobile_no" id="mobile_no" class="form-control" required>
                            </div>

                            <button type="submit" class="btn btn-primary">Create Retail Store</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\zk\resources\views/retails/create.blade.php ENDPATH**/ ?>