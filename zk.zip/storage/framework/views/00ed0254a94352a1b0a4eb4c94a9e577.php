 

<?php $__env->startSection('content'); ?>
    <h5>Add New Category</h5>
    <form action="<?php echo e(route('categories.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" id="name" placeholder="Category Name">
        <button type="submit">Add Category</button>
    </form>
        <h5>All Categories</h5>
        <table class="table col-md-6">
            <thead class="col-md-6">
                <tr class="row-md-6">
                    <th class="col-md-3">Category Name</th>
                    <th class="col-md-3">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="col-md-3"><?php echo e($category->name); ?></td>
                        <td class="col-md-3">
                            <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\zk\resources\views/items/categories.blade.php ENDPATH**/ ?>