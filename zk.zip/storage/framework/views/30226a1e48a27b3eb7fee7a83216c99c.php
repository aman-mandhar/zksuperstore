<!-- resources/views/stocks/create.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Add Stock')); ?></div>

                <div class="card-body">
                    <form method="post" action="<?php echo e(route('stocks.store')); ?>">
                        <?php echo csrf_field(); ?> 
            
                        
                        <div class="form-group">
                            <label for="name">Item Name</label>
                            <select name="name" id="name" class="form-control" required>
                                <option value="" disabled selected>Select an item</option>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->name); ?>" data-type="<?php echo e($item->type); ?>"><?php echo e($item->name); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                                   
                        
                        <div class="form-group" id="measureField" style="display: none;">
                            <label for="measure">Measure (in kilograms and grams)</label>
                            <input type="text" name="measure" id="measure" class="form-control">
                        </div>
            
                        
                        <div class="form-group" id="totNoOfItemsField" style="display: none;">
                            <label for="tot_no_of_items">Total Number of Items</label>
                            <input type="number" name="tot_no_of_items" id="tot_no_of_items" class="form-control">
                        </div>
            
                        
                    
                    <div class="form-group row">
                        <label for="pur_value" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Purchase Value of Item')); ?></label>
                        <div class="col-md-6">
                            <input id="pur_value" type="number" step="0.01" class="form-control <?php $__errorArgs = ['pur_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pur_value" value="<?php echo e(old('pur_value')); ?>" required>
                            <?php $__errorArgs = ['pur_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <div class="form-group row">
                      <label for="mrp" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Maximum Retail Price')); ?></label>
                      <div class="col-md-6">
                          <input id="mrp" type="number" step="0.01" class="form-control <?php $__errorArgs = ['mrp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="mrp" value="<?php echo e(old('mrp')); ?>" required>
                          <?php $__errorArgs = ['mrp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($message); ?></strong>
                              </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  </div>
                  
            
            <div class="form-group row">
                <label for="pur_bill_no" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Purchase Bill Number')); ?></label>
                <div class="col-md-6">
                    <input id="pur_bill_no" type="text" class="form-control <?php $__errorArgs = ['pur_bill_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pur_bill_no" value="<?php echo e(old('pur_bill_no')); ?>" required>
                    <?php $__errorArgs = ['pur_bill_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="form-group row">
                <label for="merchant" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Merchant')); ?></label>
                <div class="col-md-6">
                    <input id="merchant" type="text" class="form-control <?php $__errorArgs = ['merchant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="merchant" value="<?php echo e(old('merchant', 'Open Market')); ?>" nullable>
                    <?php $__errorArgs = ['merchant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="form-group row">
                <label for="sale_price" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Sale Price of Item')); ?></label>
                <div class="col-md-6">
                    <input id="sale_price" type="number" step="0.01" class="form-control <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="sale_price" value="<?php echo e(old('sale_price')); ?>" required>
                    <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="form-group row">
                <label for="tot_points" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Total Points')); ?></label>
                <div class="col-md-6">
                    <input id="tot_points" type="number" step="0.01" class="form-control <?php $__errorArgs = ['tot_points'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tot_points" value="<?php echo e(old('tot_points', '0.00')); ?>" required>
                    <?php $__errorArgs = ['tot_points'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                           
                           <div class="form-group">
                           <input type="text" name="user_id" value="<?php echo e(auth()->id()); ?>" readonly>
            </div>
        </div>
           

            
            <!-- Add other form fields as per your schema -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Add Stock')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('name').addEventListener('change', function () {
        var selectedItem = this.options[this.selectedIndex];
        var itemType = selectedItem.getAttribute('data-type');
        var measureField = document.getElementById('measureField');
        var totNoOfItemsField = document.getElementById('totNoOfItemsField');

        // Hide both fields initially
        measureField.style.display = 'none';
        totNoOfItemsField.style.display = 'none';

        // Fetch the 'type' attribute from the selected item
        var itemTypeName = selectedItem.getAttribute('data-type');
        
        // Show the relevant field based on the item type
        if (itemTypeName === 'Loose') {
            measureField.style.display = 'block';
            // Reset the tot_no_of_items field
            document.getElementById('tot_no_of_items').value = '';
        } else {
            totNoOfItemsField.style.display = 'block';
            // Reset the measure field
            document.getElementById('measure').value = '';
        }
    });
</script>

   
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\zk\resources\views/stocks/edit.blade.php ENDPATH**/ ?>