
<?php $__env->startSection('content'); ?>
    <h5>Add New Variation</h5>
    <form action="<?php echo e(route('variations.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="item_id">Item</label>
            <select name="item_id" id="item_id" class="form-control">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="subcategory_id">Sub Category</label>
            <select name="subcategory_id" id="subcategory_id" class="form-control">
                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($subcategory->id); ?>"><?php echo e($subcategory->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="color">Color</label>
            <input type="text" name="color" id="color" class="form-control">
        </div>
        <div class="form-group">
            <label for="size">Size</label>
            <input type="text" name="size" id="size" class="form-control">
        </div>
        <button type="submit">Add Variation</button>
    </form>
    <h5>All Variations</h5>
    <table class="table col-md-6">
        <thead class="col-md-6">
            <tr class="row-md-6">
                <th class="col-md-3">Item Name</th>
                <th class="col-md-3">Variation Name</th>
                <th class="col-md-3">Sub Category</th>
                <th class="col-md-3">Category</th>
                <th class="col-md-3">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="col-md-3"><?php echo e($variation->item->name); ?></td>
                    <td class="col-md-3"><?php echo e($variation->name); ?></td>
                    <td class="col-md-3"><?php echo e($variation->item->sub_category->name); ?></td>
                    <td class="col-md-3"><?php echo e($variation->item->sub_category->category->name); ?></td>
                    <td class="col-md-3">
                        <form action="<?php echo e(route('variations.destroy', $variation->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\zk\resources\views/items/variations.blade.php ENDPATH**/ ?>